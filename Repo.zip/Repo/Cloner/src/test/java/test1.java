package Repo;

import com.google.common.base.CaseFormat;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.api.errors.GitAPIException;
import org.eclipse.jgit.transport.UsernamePasswordCredentialsProvider;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;

public class test1 {
private String localPath;
private Repository localRepo;
private Git git;

localPath = "/home/test/git_repo_test";
remotePath = "https://github.com/test/repo_1.git";

try {
    localRepo = new FileRepository(localPath + "/.git");
} catch (IOException e) {
    e.printStackTrace();  
}
git = new Git(localRepo);

PullCommand pullCmd = git.pull();
try {
    pullCmd.call();
} catch (GitAPIException e) {
    e.printStackTrace();  
}
}
